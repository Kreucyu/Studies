import java.util.Scanner;

public class Questao3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite sua unidade de medida:");
        String a = sc.next();
        String opcao = a.toUpperCase();
        if (opcao.equals("M")){
            System.out.println("Metros");
        } else if (opcao.equals("H")){
            System.out.println("Horas");
        } else if (opcao.equals("S")){
            System.out.println("Segundos");
        } else {
            System.out.println("Entrada Incorreta");
        } sc.close();
    }
}
