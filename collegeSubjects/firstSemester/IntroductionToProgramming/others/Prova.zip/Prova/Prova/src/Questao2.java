import java.util.Scanner;

public class Questao2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite as temperaturas");
        float temp1 = sc.nextFloat();
        float temp2 = sc.nextFloat();
        float temp3 = sc.nextFloat();
        System.out.println("O que você deseja saber?");
        System.out.println("A - Temperatura mais alta");
        System.out.println("B - Temperatura mais baixa");
        System.out.println("C - Ordem descrescente das temperaturas");
        System.out.println("D - Média das temperaturas");
        String op = sc.next();
        String opcao = op.toUpperCase();

        switch (opcao) {
            case "A":
            if (temp1 > temp2 && temp1 > temp3) {
                System.out.println("A temperatura mais alta é " + temp1);
            } else if (temp2 > temp1 && temp2 > temp3) {
                System.out.println("A temperatura mais alta é " + temp2);

            } else if (temp3 > temp1 && temp3 > temp2) {
                System.out.println("A temperatura mais alta é " + temp3);
            } break;
            case "B":
            if (temp1 < temp2 && temp1 < temp3) {
                System.out.println("A temperatura mais baixa é " + temp1);
            } else if (temp2 < temp1 && temp2 < temp3) {
                System.out.println("A temperatura mais baixa é " + temp2);
            } else if (temp3 < temp1 && temp3 < temp2) {
                System.out.println("A temperatura mais baixa é " + temp3);
            } break;
            case "C":
            if (temp1 > temp2 && temp2 > temp3) {
                System.out.println("A ordem é: " + temp1 + ", " + temp2 + ", " + temp3);
            } else if (temp2 > temp1 && temp1 > temp3) {
                System.out.println("A ordem é: " + temp2 + ", " + temp1 + ", " + temp3);
            } else if (temp3 > temp1 && temp1 > temp2) {
                System.out.println("A ordem é: " + temp3 + ", " + temp1 + ", " + temp2);
            } else if (temp3 > temp2 && temp2 > temp1) {
                System.out.println("A ordem é: " + temp3 + ", " + temp2 + ", " + temp1);
            } else if (temp1 > temp3 && temp3 > temp2) {
                System.out.println("A ordem é: " + temp1 + ", " + temp3 + ", " + temp2);
            } else if (temp2 > temp3 && temp3 > temp1) {
                System.out.println("A ordem é: " + temp2 + ", " + temp3 + ", " + temp1);
            } break;
            case "D":
            float media = (temp1 + temp2 + temp3) / 3;
            System.out.println("A média das temperaturas é " + media + " graus celcius");
            break;
        } sc.close();
    }
}
