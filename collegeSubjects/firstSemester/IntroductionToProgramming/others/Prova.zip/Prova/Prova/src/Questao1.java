import java.util.Scanner;

public class Questao1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String disciplina = sc.nextLine();
        String professor = sc.nextLine();

        if (disciplina.equals("") && professor.equals("")) {
            System.out.println("Não é possível informar os dados");
            System.out.println("Vazio");
            System.out.println("FIM");
        } else {
            System.out.println("disciplina: " + disciplina);
            if (professor.equals("")) {
                System.out.println("Professor Vazio");
                System.out.println("FIM");
            } else {
                System.out.println("Professor: " + professor);
                System.out.println("FIM");
            }
        } sc.close();
    }
}
