import java.util.Scanner;

public class Uni5Exe01 {
    public static void main(String[] args) {
        for (int n = 0; n <= 20; n++) {

            if (n % 2 == 0) {
                System.out.println("\n " + n + " número par");
            } else {
                System.out.println( "\n " + n + " número ímpar");
            }
        } 
    }
}
