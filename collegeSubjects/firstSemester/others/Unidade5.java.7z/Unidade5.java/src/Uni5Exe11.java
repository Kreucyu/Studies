public class Uni5Exe11 {
    public static void main(String[] args) {
        int hora = 16;
        int biscoito = 1;
       
        for (int i = 1; i < hora; i++) {
                biscoito *= 3;
        }
        System.out.println("\nEm " + hora + " horas, foram quebrados " + biscoito + " biscoitos");
    } 
}
